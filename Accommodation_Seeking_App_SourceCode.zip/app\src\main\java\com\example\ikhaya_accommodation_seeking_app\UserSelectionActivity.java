package com.example.ikhaya_accommodation_seeking_app;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.util.HashSet;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UserSelectionActivity extends AppCompatActivity {

    private static final String TAG = "UserSelection";

    private LinearLayout usersListContainer;
    private LinearLayout searchResultsContainer;
    private ProgressBar progressUsers;
    private EditText editSearchUser;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private String currentUserId;
    private String currentUserName;
    private String currentUserRole;
    private String accessToken;

    private volatile boolean messagesScreenVisible = false;
    private volatile boolean markingMessages = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_selection);

        View btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        usersListContainer = findViewById(R.id.usersListContainer);
        searchResultsContainer = findViewById(R.id.searchResultsContainer);
        progressUsers = findViewById(R.id.progressUsers);
        editSearchUser = findViewById(R.id.editSearchUser);

        CardView cardCommunityChat = findViewById(R.id.cardCommunityChat);
        View btnViewAlerts = findViewById(R.id.btnViewAlerts);
        TextView txtRoleBadge = findViewById(R.id.txtRoleBadge);

        accessToken = SupabaseHelper.getAccessToken(this);
        currentUserId = SupabaseHelper.getUserId(this);

        SharedPreferences prefs = getSharedPreferences("iKhayaSession", MODE_PRIVATE);
        currentUserName = prefs.getString("USER_NAME", getString(R.string.default_chat_user_name));
        currentUserRole = prefs.getString("USER_ROLE", getString(R.string.default_chat_member_role));

        if (txtRoleBadge != null) {
            txtRoleBadge.setText(String.format(Locale.getDefault(), "%s ●", currentUserRole.toUpperCase(Locale.getDefault())));
        }

        if (cardCommunityChat != null) {
            cardCommunityChat.setOnClickListener(v ->
                    openChat("COMMUNITY", "🌍 " + getString(R.string.subtitle_community_room), true)
            );
        }

        if (btnViewAlerts != null) {
            btnViewAlerts.setOnClickListener(v ->
                    startActivity(new Intent(this, NotificationsActivity.class))
            );
        }

        if (editSearchUser != null) {
            editSearchUser.setOnEditorActionListener((v, actionId, event) -> {
                if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                    searchUsers(editSearchUser.getText().toString().trim());
                    return true;
                }
                return false;
            });
        }

        setupBottomNavigation();
        loadActiveChats();
    }

    private void setupBottomNavigation() {
        View userSelectionRoot = findViewById(R.id.userSelectionRoot);
        View floatingBottomNav = findViewById(R.id.floatingBottomNav);

        SharedPreferences prefs = getSharedPreferences("iKhayaSession", MODE_PRIVATE);
        String role = prefs.getString("USER_ROLE", "");
        boolean isLandlord = getIntent().getBooleanExtra("isLandlord", "landlord".equalsIgnoreCase(role) || "ADMIN".equalsIgnoreCase(role));

        if (floatingBottomNav != null) {
            floatingBottomNav.setPadding(0, 0, 0, 0);

            if (userSelectionRoot != null) {
                ViewCompat.setOnApplyWindowInsetsListener(userSelectionRoot, (v, insets) -> {
                    Insets statusBar = insets.getInsets(WindowInsetsCompat.Type.statusBars());
                    Insets navBar = insets.getInsets(WindowInsetsCompat.Type.navigationBars());

                    v.setPadding(0, statusBar.top, 0, 0);

                    if (floatingBottomNav.getLayoutParams() instanceof CoordinatorLayout.LayoutParams) {
                        CoordinatorLayout.LayoutParams lp = (CoordinatorLayout.LayoutParams) floatingBottomNav.getLayoutParams();
                        int baseMarginPx = Math.round(16f * getResources().getDisplayMetrics().density);
                        lp.bottomMargin = navBar.bottom + baseMarginPx;
                        floatingBottomNav.setLayoutParams(lp);
                        floatingBottomNav.setPadding(0, 0, 0, 0);
                    }

                    return WindowInsetsCompat.CONSUMED;
                });
            }

            if (isLandlord) {
                View navHome = findViewById(R.id.navHome);
                ImageView imgNavHome = findViewById(R.id.imgNavHome);
                TextView tvNavHome = findViewById(R.id.tvNavHome);

                if (imgNavHome != null) imgNavHome.setImageResource(R.drawable.layout_dashboard);
                if (tvNavHome != null) tvNavHome.setText(R.string.nav_dashboard);

                if (navHome != null) {
                    navHome.setOnClickListener(v -> {
                        Intent intent = new Intent(UserSelectionActivity.this, LandlordDashboardActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(intent);
                        finish();
                    });
                }

                View navFavorites = findViewById(R.id.navFavorites);
                ImageView imgNavFavorites = findViewById(R.id.imgNavFavorites);
                TextView tvNavFavorites = findViewById(R.id.tvNavFavorites);

                if (imgNavFavorites != null) imgNavFavorites.setImageResource(R.drawable.book_user);
                if (tvNavFavorites != null) tvNavFavorites.setText(R.string.listings);

                if (navFavorites != null) {
                    navFavorites.setOnClickListener(v -> {
                        Intent intent = new Intent(UserSelectionActivity.this, MyListingsActivity.class);
                        intent.putExtra("FILTER_STATUS", "ALL");
                        startActivity(intent);
                        finish();
                    });
                }

                View navViewings = findViewById(R.id.navViewings);
                ImageView imgNavViewings = findViewById(R.id.imgNavViewings);
                TextView tvNavViewings = findViewById(R.id.tvNavViewings);

                if (imgNavViewings != null) imgNavViewings.setImageResource(R.drawable.ic_plus_circle);
                if (tvNavViewings != null) tvNavViewings.setText(R.string.add);

                if (navViewings != null) {
                    navViewings.setOnClickListener(v -> {
                        Intent intent = new Intent(UserSelectionActivity.this, AddListingActivity.class);
                        startActivity(intent);
                        finish();
                    });
                }
            } else {
                View navHome = findViewById(R.id.navHome);
                if (navHome != null) {
                    navHome.setOnClickListener(v -> {
                        Intent intent = new Intent(UserSelectionActivity.this, HomeActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(intent);
                        finish();
                    });
                }

                View navFavorites = findViewById(R.id.navFavorites);
                if (navFavorites != null) {
                    navFavorites.setOnClickListener(v -> {
                        startActivity(new Intent(UserSelectionActivity.this, SavedListingsActivity.class));
                        finish();
                    });
                }

                View navViewings = findViewById(R.id.navViewings);
                if (navViewings != null) {
                    navViewings.setOnClickListener(v -> {
                        startActivity(new Intent(UserSelectionActivity.this, ViewingsActivity.class));
                        finish();
                    });
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        messagesScreenVisible = true;

        accessToken = SupabaseHelper.getAccessToken(this);
        String userId = SupabaseHelper.getUserId(this);
        if (userId != null && !userId.isEmpty()) {
            currentUserId = userId;
        }

        loadActiveChats();
        markIncomingMessagesSeen();
    }

    @Override
    protected void onPause() {
        messagesScreenVisible = false;
        super.onPause();
    }

    private void markIncomingMessagesSeen() {
        if (markingMessages) {
            return;
        }

        String userId = SupabaseHelper.getUserId(this);
        String token = SupabaseHelper.getAccessToken(this);

        if (userId == null || userId.isEmpty() || token == null || token.isEmpty()) {
            return;
        }

        markingMessages = true;

        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                String endpoint = "/rest/v1/messages?select=id&receiver_id=eq."
                        + SupabaseHelper.encode(userId)
                        + "&order=created_at.desc&limit=1000";

                connection = SupabaseHelper.createConnection(endpoint, "GET", token);
                int code = connection.getResponseCode();
                String response = SupabaseHelper.readResponse(connection);

                if (code >= 200 && code < 300) {
                    JSONArray rows = new JSONArray(response);
                    LandlordNotificationState.markSeen(getApplicationContext(), "messages", userId, rows);
                    TenantNotificationState.markSeen(getApplicationContext(), userId, "messages", rows);
                }
            } catch (Exception e) {
                Log.w(TAG, "Could not mark messages as seen", e);
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                markingMessages = false;
            }
        });
    }

    private void loadActiveChats() {
        if (accessToken == null || accessToken.isEmpty()) {
            if (progressUsers != null) progressUsers.setVisibility(View.GONE);
            return;
        }

        executor.execute(() -> {
            HttpURLConnection connReqs = null;
            HttpURLConnection connMsgs = null;
            try {
                String encId = SupabaseHelper.encode(currentUserId);

                // 1. Fetch accepted chat requests
                String reqEndpoint = "/rest/v1/chat_requests?or=(sender_id.eq."
                        + encId + ",receiver_id.eq." + encId
                        + ")&status=eq.accepted&order=created_at.desc";

                connReqs = SupabaseHelper.createConnection(reqEndpoint, "GET", accessToken);
                JSONArray requestsArray = connReqs.getResponseCode() >= 200 && connReqs.getResponseCode() < 300
                        ? new JSONArray(SupabaseHelper.readResponse(connReqs))
                        : new JSONArray();

                // 2. Fetch all direct messages sent or received to catch host/viewing chats
                String msgEndpoint = "/rest/v1/messages?or=(sender_id.eq."
                        + encId + ",receiver_id.eq." + encId
                        + ")&receiver_id=neq.COMMUNITY&order=created_at.desc&limit=100";

                connMsgs = SupabaseHelper.createConnection(msgEndpoint, "GET", accessToken);
                JSONArray messagesArray = connMsgs.getResponseCode() >= 200 && connMsgs.getResponseCode() < 300
                        ? new JSONArray(SupabaseHelper.readResponse(connMsgs))
                        : new JSONArray();

                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    if (progressUsers != null) progressUsers.setVisibility(View.GONE);
                    mergeAndDisplayChats(requestsArray, messagesArray);
                });

            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (progressUsers != null) progressUsers.setVisibility(View.GONE);
                });
            } finally {
                if (connReqs != null) connReqs.disconnect();
                if (connMsgs != null) connMsgs.disconnect();
            }
        });
    }

    private void mergeAndDisplayChats(JSONArray requestsArray, JSONArray messagesArray) {
        if (usersListContainer == null) return;
        usersListContainer.removeAllViews();

        HashSet<String> seenUserIds = new HashSet<>();

        // Add confirmed contacts from chat_requests
        for (int i = 0; i < requestsArray.length(); i++) {
            JSONObject reqObj = requestsArray.optJSONObject(i);
            if (reqObj == null) continue;

            String senderId = reqObj.optString("sender_id");
            String receiverId = reqObj.optString("receiver_id");

            String targetUserId, targetName, targetRole;
            if (currentUserId.equals(senderId)) {
                targetUserId = receiverId;
                targetName = reqObj.optString("receiver_name", getString(R.string.notification_user));
                targetRole = reqObj.optString("receiver_role", getString(R.string.notification_member));
            } else {
                targetUserId = senderId;
                targetName = reqObj.optString("sender_name", getString(R.string.notification_user));
                targetRole = reqObj.optString("sender_role", getString(R.string.notification_member));
            }

            if (!targetUserId.isEmpty() && !seenUserIds.contains(targetUserId)) {
                seenUserIds.add(targetUserId);
                addUserCard(targetUserId, targetName, targetRole, usersListContainer, getString(R.string.tap_to_message));
            }
        }

        // Add contacts discovered from actual message threads (like Scheduled Viewings)
        for (int i = 0; i < messagesArray.length(); i++) {
            JSONObject msgObj = messagesArray.optJSONObject(i);
            if (msgObj == null) continue;

            String senderId = msgObj.optString("sender_id");
            String receiverId = msgObj.optString("receiver_id");

            String targetUserId = currentUserId.equals(senderId) ? receiverId : senderId;
            if (targetUserId.isEmpty() || seenUserIds.contains(targetUserId)) continue;

            String targetName = currentUserId.equals(senderId)
                    ? (targetUserId.length() > 8 ? "Host (" + targetUserId.substring(0, 6) + ")" : "Host")
                    : msgObj.optString("sender_name", "Host");

            String targetRole = currentUserId.equals(senderId) ? "landlord" : msgObj.optString("sender_role", "member");

            seenUserIds.add(targetUserId);
            addUserCard(targetUserId, targetName, targetRole, usersListContainer, getString(R.string.tap_to_message));
        }

        if (seenUserIds.isEmpty()) {
            TextView emptyText = new TextView(this);
            emptyText.setText(R.string.no_active_direct_chats);
            emptyText.setTextColor(Color.parseColor("#6C757D"));
            emptyText.setTextSize(14f);
            emptyText.setPadding(0, dpToPx(8), 0, dpToPx(8));
            usersListContainer.addView(emptyText);
        }
    }

    private void searchUsers(String query) {
        if (query.isEmpty()) return;

        Toast.makeText(this, R.string.searching_users_toast, Toast.LENGTH_SHORT).show();
        if (searchResultsContainer != null) {
            searchResultsContainer.removeAllViews();
        }

        executor.execute(() -> {
            HttpURLConnection connProfiles = null;
            HttpURLConnection connUsers = null;

            try {
                connProfiles = SupabaseHelper.createConnection("/rest/v1/profiles?select=*", "GET", accessToken);
                int codeProfiles = connProfiles.getResponseCode();
                String responseProfiles = SupabaseHelper.readResponse(connProfiles);
                JSONArray profilesArray = codeProfiles >= 200 && codeProfiles < 300
                        ? new JSONArray(responseProfiles)
                        : new JSONArray();

                connUsers = SupabaseHelper.createConnection("/rest/v1/Users?select=*", "GET", accessToken);
                int codeUsers = connUsers.getResponseCode();
                String responseUsers = SupabaseHelper.readResponse(connUsers);
                JSONArray usersArray = codeUsers >= 200 && codeUsers < 300
                        ? new JSONArray(responseUsers)
                        : new JSONArray();

                runOnUiThread(() -> {
                    if (!isFinishing() && !isDestroyed()) {
                        renderDualSearchResults(profilesArray, usersArray, query.toLowerCase(Locale.getDefault()));
                    }
                });

            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (!isFinishing() && !isDestroyed()) {
                        Toast.makeText(this, getString(R.string.error_during_search_prefix) + " " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            } finally {
                if (connProfiles != null) connProfiles.disconnect();
                if (connUsers != null) connUsers.disconnect();
            }
        });
    }

    private void renderDualSearchResults(JSONArray profilesArray, JSONArray usersArray, String queryLower) {
        try {
            boolean found = false;
            HashSet<String> seenIds = new HashSet<>();

            for (int i = 0; i < profilesArray.length(); i++) {
                JSONObject obj = profilesArray.getJSONObject(i);

                String userId = obj.optString("firebase_uid", "");
                if (userId.isEmpty()) {
                    userId = obj.optString("id", "");
                }

                if (userId.isEmpty() || userId.equals(currentUserId) || seenIds.contains(userId)) {
                    continue;
                }

                String fullName = obj.optString("full_name", "");
                if (fullName.isEmpty()) {
                    fullName = obj.optString("firstName", "");
                }
                if (fullName.isEmpty()) {
                    fullName = obj.optString("email", getString(R.string.notification_user));
                }

                String role = obj.optString("role", getString(R.string.notification_member));

                if (fullName.toLowerCase(Locale.getDefault()).contains(queryLower)) {
                    seenIds.add(userId);
                    found = true;
                    addUserCard(userId, fullName, role, searchResultsContainer, getString(R.string.request_chat));
                }
            }

            for (int i = 0; i < usersArray.length(); i++) {
                JSONObject obj = usersArray.getJSONObject(i);

                String userId = obj.optString("id", "");
                if (userId.isEmpty() || userId.equals(currentUserId) || seenIds.contains(userId)) {
                    continue;
                }

                String firstName = obj.optString("firstName", "");
                String surname = obj.optString("surname", "");
                String fullName = (firstName + " " + surname).trim();
                if (fullName.isEmpty()) {
                    fullName = obj.optString("email", getString(R.string.notification_user));
                }

                String role = obj.optString("user_role", getString(R.string.notification_member));

                if (fullName.toLowerCase(Locale.getDefault()).contains(queryLower)) {
                    seenIds.add(userId);
                    found = true;
                    addUserCard(userId, fullName, role, searchResultsContainer, getString(R.string.request_chat));
                }
            }

            if (!found) {
                Toast.makeText(this, R.string.no_matching_users_found, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Could not display search results", e);
        }
    }

    private void showContactDeleteMenu(View anchor, String targetUid) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add(R.string.menu_delete_contact_and_chat);
        popup.setOnMenuItemClickListener(item -> {
            if (item.getTitle() != null && item.getTitle().equals(getString(R.string.menu_delete_contact_and_chat))) {
                new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle(R.string.dialog_title_delete_contact)
                        .setMessage(R.string.dialog_msg_delete_contact_confirm)
                        .setPositiveButton(R.string.btn_delete, (dialog, which) -> deleteContactAndChat(targetUid))
                        .setNegativeButton(R.string.btn_cancel, null)
                        .show();
            }
            return true;
        });
        popup.show();
    }

    private void deleteContactAndChat(String targetUid) {
        String myUid = SupabaseHelper.getUserId(this);
        String token = SupabaseHelper.getAccessToken(this);
        if (myUid == null || token == null) return;

        executor.execute(() -> {
            try {
                String encodedMy = SupabaseHelper.encode(myUid);
                String encodedTarget = SupabaseHelper.encode(targetUid);

                String endpointMsg = "/rest/v1/messages?or=(and(sender_id.eq." + encodedMy + ",receiver_id.eq." + encodedTarget
                        + "),and(sender_id.eq." + encodedTarget + ",receiver_id.eq." + encodedMy + "))";
                HttpURLConnection connMsg = SupabaseHelper.createConnection(endpointMsg, "DELETE", token);
                connMsg.getResponseCode();
                connMsg.disconnect();

                String endpointReq = "/rest/v1/chat_requests?or=(and(sender_id.eq." + encodedMy + ",receiver_id.eq." + encodedTarget
                        + "),and(sender_id.eq." + encodedTarget + ",receiver_id.eq." + encodedMy + "))";
                HttpURLConnection connReq = SupabaseHelper.createConnection(endpointReq, "DELETE", token);
                connReq.getResponseCode();
                connReq.disconnect();

                runOnUiThread(() -> {
                    Toast.makeText(this, R.string.toast_chat_deleted, Toast.LENGTH_SHORT).show();
                    recreate();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, R.string.error_failed_to_delete_contact, Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void addUserCard(String targetUserId, String targetName, String targetRole, LinearLayout parent, String actionText) {
        if (parent == null) return;

        CardView card = new CardView(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(0, 0, 0, dpToPx(12));
        card.setLayoutParams(cardParams);
        card.setRadius(dpToPx(16));
        card.setCardElevation(dpToPx(3));
        card.setCardBackgroundColor(Color.WHITE);

        LinearLayout innerLayout = new LinearLayout(this);
        innerLayout.setOrientation(LinearLayout.HORIZONTAL);
        innerLayout.setGravity(Gravity.CENTER_VERTICAL);
        int pad = dpToPx(16);
        innerLayout.setPadding(pad, pad, pad, pad);

        LinearLayout textLayout = new LinearLayout(this);
        textLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f
        );
        textLayout.setLayoutParams(textParams);

        TextView txtName = new TextView(this);
        txtName.setText(targetName);
        txtName.setTextSize(16f);
        txtName.setTypeface(null, Typeface.BOLD);
        txtName.setTextColor(Color.parseColor("#1F1614"));

        TextView txtRole = new TextView(this);
        txtRole.setText(String.format(Locale.getDefault(), "%s • %s", targetRole.toUpperCase(Locale.getDefault()), actionText));
        txtRole.setTextSize(12f);
        txtRole.setTextColor(Color.parseColor("#6C757D"));

        textLayout.addView(txtName);
        textLayout.addView(txtRole);
        innerLayout.addView(textLayout);

        if (!getString(R.string.request_chat).equals(actionText)) {
            TextView btnOptions = new TextView(this);
            btnOptions.setText("⋮");
            btnOptions.setTextSize(20f);
            btnOptions.setTypeface(null, Typeface.BOLD);
            btnOptions.setTextColor(Color.parseColor("#6C757D"));
            btnOptions.setPadding(dpToPx(12), dpToPx(6), dpToPx(6), dpToPx(6));
            btnOptions.setBackgroundResource(R.drawable.selector_regular_button);
            btnOptions.setBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));

            btnOptions.setOnClickListener(v -> showContactDeleteMenu(btnOptions, targetUserId));
            innerLayout.addView(btnOptions);
        }

        card.addView(innerLayout);

        card.setOnClickListener(v -> {
            if (getString(R.string.request_chat).equals(actionText)) {
                checkAndRequestChat(targetUserId, targetName, targetRole);
            } else {
                openChat(targetUserId, targetName, false);
            }
        });

        parent.addView(card);
    }

    private void checkAndRequestChat(String targetUserId, String targetName, String targetRole) {
        Toast.makeText(this, R.string.toast_checking_request_status, Toast.LENGTH_SHORT).show();

        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                String encCurrent = SupabaseHelper.encode(currentUserId);
                String encTarget = SupabaseHelper.encode(targetUserId);
                String endpoint = "/rest/v1/chat_requests?or=(and(sender_id.eq."
                        + encCurrent
                        + ",receiver_id.eq."
                        + encTarget
                        + "),and(sender_id.eq."
                        + encTarget
                        + ",receiver_id.eq."
                        + encCurrent
                        + "))";

                conn = SupabaseHelper.createConnection(endpoint, "GET", accessToken);
                int code = conn.getResponseCode();
                String response = SupabaseHelper.readResponse(conn);

                if (code >= 200 && code < 300) {
                    JSONArray reqs = new JSONArray(response);
                    if (reqs.length() > 0) {
                        JSONObject req = reqs.getJSONObject(0);
                        String status = req.optString("status");
                        if ("accepted".equalsIgnoreCase(status)) {
                            runOnUiThread(() -> openChat(targetUserId, targetName, false));
                        } else {
                            runOnUiThread(() ->
                                    Toast.makeText(this, R.string.toast_request_already_pending, Toast.LENGTH_LONG).show()
                            );
                        }
                    } else {
                        runOnUiThread(() -> showRequestDialog(targetUserId, targetName, targetRole));
                    }
                } else {
                    runOnUiThread(() ->
                            Toast.makeText(this, getString(R.string.error_send_failed_http) + " " + response, Toast.LENGTH_LONG).show()
                    );
                }
            } catch (Exception e) {
                runOnUiThread(() ->
                        Toast.makeText(this, getString(R.string.error_during_search_prefix) + " " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    private void showRequestDialog(String targetUserId, String targetName, String targetRole) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_title_send_chat_request)
                .setMessage(getString(R.string.dialog_msg_send_chat_request, targetName, targetRole))
                .setPositiveButton(R.string.btn_send_request, (dialog, which) ->
                        sendChatRequest(targetUserId, targetName, targetRole)
                )
                .setNegativeButton(R.string.btn_cancel, null)
                .show();
    }

    private void sendChatRequest(String targetUserId, String targetName, String targetRole) {
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                conn = SupabaseHelper.createConnection("/rest/v1/chat_requests", "POST", accessToken);
                conn.setRequestProperty("Prefer", "return=minimal");

                JSONObject body = new JSONObject();
                body.put("sender_id", currentUserId);
                body.put("sender_name", currentUserName);
                body.put("sender_role", currentUserRole);
                body.put("receiver_id", targetUserId);
                body.put("receiver_name", targetName);
                body.put("receiver_role", targetRole);
                body.put("status", "pending");

                SupabaseHelper.writeJson(conn, body);
                int code = conn.getResponseCode();

                if (code >= 200 && code < 300) {
                    runOnUiThread(() ->
                            Toast.makeText(this, R.string.toast_chat_request_sent, Toast.LENGTH_SHORT).show()
                    );
                } else {
                    String error = SupabaseHelper.readResponse(conn);
                    runOnUiThread(() ->
                            Toast.makeText(this, getString(R.string.error_send_failed_http) + " " + error, Toast.LENGTH_LONG).show()
                    );
                }
            } catch (Exception e) {
                runOnUiThread(() ->
                        Toast.makeText(this, R.string.error_sending_message_prefix, Toast.LENGTH_SHORT).show()
                );
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    private void openChat(String receiverId, String receiverName, boolean isCommunity) {
        Intent intent = new Intent(this, ChatActivity.class);
        intent.putExtra("RECEIVER_ID", receiverId);
        intent.putExtra("RECEIVER_NAME", receiverName);
        intent.putExtra("IS_COMMUNITY", isCommunity);
        intent.putExtra("SENDER_ID", currentUserId);
        intent.putExtra("SENDER_NAME", currentUserName);
        intent.putExtra("SENDER_ROLE", currentUserRole);
        startActivity(intent);
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}